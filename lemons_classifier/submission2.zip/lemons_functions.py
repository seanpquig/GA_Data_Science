def isAmerican(nationality):
    if nationality == 'AMERICAN':
        return 1
    else:
        return 0
def isAsian(nationality):
    if nationality == 'OTHER ASIAN':
        return 1
    else:
        return 0
def isFord(top3):
    if top3 == 'FORD':
        return 1
    else:
        return 0
def isChrysler(top3):
    if top3 == 'CHRYSLER':
        return 1
    else:
        return 0
def isGM(top3):
    if top3 == 'GM':
        return 1
    else:
        return 0

def isAdesa(auction):
    if auction == 'ADESA':
        return 1
    else:
        return 0
def isMan(auction):
    if auction == 'MANHEIM':
        return 1
    else:
        return 0
def isOther(auction):
    if auction == 'OTHER':
        return 1
    else:
        return 0

